"use client";

import { FormEvent, ReactNode, useEffect, useMemo, useRef, useState } from "react";
import initialDashboardData from "../data/thesis-dashboard.json";

type TaskStatus = "todo" | "doing" | "blocked" | "done";
type Priority = "high" | "medium" | "low";

type Chapter = { id: string; number: string; title: string; subtitle: string; goal: string; sections: string[] };
type Task = { id: string; chapterId: string; title: string; status: TaskStatus; priority: Priority; type: string; due: string };
type Reference = { id: string; key: string; authors: string; year: string; title: string; status: string; chapterIds: string[]; url: string; note: string };
type Feedback = { id: string; date: string; author: string; summary: string; action: string; status: string; chapterIds: string[]; source: string };
type Experiment = { id: string; code: string; rq: string; title: string; status: string; next: string; taskIds: string[] };
type Decision = { id: string; date: string; title: string; detail: string; status: string };
type DashboardData = {
  meta: {
    title: string; degree: string; currentPhase: string; updatedAt: string;
    nextMilestone: string; researchQuestion: string; supervisors: { name: string; role: string }[];
  };
  chapters: Chapter[]; tasks: Task[]; references: Reference[]; feedback: Feedback[];
  experiments: Experiment[]; decisions: Decision[];
};
type View = "overview" | "structure" | "tasks" | "references" | "feedback" | "experiments";
type LocalFileHandle = {
  getFile: () => Promise<File>;
  createWritable: () => Promise<{ write: (data: string) => Promise<void>; close: () => Promise<void> }>;
  queryPermission?: (options?: { mode: "readwrite" }) => Promise<PermissionState>;
  requestPermission?: (options?: { mode: "readwrite" }) => Promise<PermissionState>;
};

const views: { id: View; label: string; short: string }[] = [
  { id: "overview", label: "总览", short: "总" },
  { id: "structure", label: "论文结构", short: "章" },
  { id: "tasks", label: "任务", short: "任" },
  { id: "references", label: "参考文献", short: "文" },
  { id: "feedback", label: "导师意见", short: "师" },
  { id: "experiments", label: "实验与数据", short: "实" },
];
const statusLabel: Record<string, string> = {
  todo: "待开始", doing: "进行中", blocked: "待确认", done: "已完成", open: "待处理",
  accepted: "已采纳", confirmed: "已确认", reading: "阅读中", using: "使用中",
};
const priorityLabel: Record<Priority, string> = { high: "高", medium: "中", low: "低" };
const formatDate = () => new Intl.DateTimeFormat("zh-CN", { dateStyle: "medium" }).format(new Date());
const progressOf = (tasks: Task[]) => tasks.length ? Math.round(tasks.filter((task) => task.status === "done").length / tasks.length * 100) : 0;
const makeId = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

function localHandleDb() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open("thesis-control-center", 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains("settings")) request.result.createObjectStore("settings");
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
async function rememberHandle(handle: LocalFileHandle) {
  const db = await localHandleDb();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction("settings", "readwrite");
    transaction.objectStore("settings").put(handle, "dashboard-file");
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
  db.close();
}
async function recalledHandle() {
  const db = await localHandleDb();
  const handle = await new Promise<LocalFileHandle | undefined>((resolve, reject) => {
    const request = db.transaction("settings", "readonly").objectStore("settings").get("dashboard-file");
    request.onsuccess = () => resolve(request.result as LocalFileHandle | undefined);
    request.onerror = () => reject(request.error);
  });
  db.close();
  return handle;
}

function ProgressRing({ value, size = 116 }: { value: number; size?: number }) {
  const radius = 43;
  const circumference = 2 * Math.PI * radius;
  return <div className="progress-ring" style={{ width: size, height: size }}>
    <svg viewBox="0 0 100 100" aria-label={`完成 ${value}%`}>
      <circle className="progress-ring-track" cx="50" cy="50" r={radius} />
      <circle className="progress-ring-value" cx="50" cy="50" r={radius} strokeDasharray={circumference} strokeDashoffset={circumference * (1 - value / 100)} />
    </svg>
    <div className="progress-ring-copy"><strong>{value}%</strong><span>总体完成</span></div>
  </div>;
}
function ProgressBar({ value }: { value: number }) {
  return <div className="bar" aria-label={`进度 ${value}%`}><span style={{ width: `${value}%` }} /></div>;
}
function StatusPill({ status }: { status: string }) {
  return <span className={`status status-${status}`}>{statusLabel[status] ?? status}</span>;
}
function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return <div className="modal-backdrop" role="presentation" onMouseDown={onClose}>
    <section className="modal" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(event) => event.stopPropagation()}>
      <header className="modal-header"><div><p className="eyebrow">论文研究控制台</p><h2>{title}</h2></div><button className="icon-button" onClick={onClose} aria-label="关闭">×</button></header>
      {children}
    </section>
  </div>;
}

export default function Home() {
  const [data, setData] = useState<DashboardData>(initialDashboardData as DashboardData);
  const [view, setView] = useState<View>("overview");
  const [fileHandle, setFileHandle] = useState<LocalFileHandle | null>(null);
  const [fileState, setFileState] = useState<"unlinked" | "linked" | "saving" | "saved" | "error">("unlinked");
  const [modal, setModal] = useState<"task" | "reference" | "feedback" | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<string | null>(null);
  const [taskFilter, setTaskFilter] = useState<TaskStatus | "all">("all");
  const [search, setSearch] = useState("");
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const overallProgress = progressOf(data.tasks);
  const activeTasks = data.tasks.filter((task) => task.status === "doing");
  const blockedTasks = data.tasks.filter((task) => task.status === "blocked");
  const openTasks = data.tasks.filter((task) => task.status !== "done");
  const chapterProgress = useMemo(
    () => Object.fromEntries(data.chapters.map((chapter) => [chapter.id, progressOf(data.tasks.filter((task) => task.chapterId === chapter.id))])),
    [data.chapters, data.tasks],
  );

  const writeFile = async (nextData: DashboardData, handle = fileHandle) => {
    if (!handle) return;
    setFileState("saving");
    try {
      const writable = await handle.createWritable();
      await writable.write(`${JSON.stringify(nextData, null, 2)}\n`);
      await writable.close();
      setFileState("saved");
    } catch { setFileState("error"); }
  };
  const updateData = (updater: (current: DashboardData) => DashboardData) => {
    setData((current) => {
      const next = updater(current);
      next.meta.updatedAt = formatDate();
      if (saveTimer.current) clearTimeout(saveTimer.current);
      if (fileHandle) saveTimer.current = setTimeout(() => void writeFile(next), 280);
      return next;
    });
  };
  const loadFromHandle = async (handle: LocalFileHandle, askPermission = false) => {
    try {
      let permission = handle.queryPermission ? await handle.queryPermission({ mode: "readwrite" }) : "granted";
      if (permission !== "granted" && askPermission && handle.requestPermission) permission = await handle.requestPermission({ mode: "readwrite" });
      if (permission !== "granted") return;
      const file = await handle.getFile();
      setData(JSON.parse(await file.text()) as DashboardData);
      setFileHandle(handle);
      setFileState("linked");
      await rememberHandle(handle);
    } catch { setFileState("error"); }
  };
  useEffect(() => {
    void recalledHandle().then((handle) => { if (handle) void loadFromHandle(handle, false); }).catch(() => undefined);
  }, []);
  const openDataFile = async () => {
    const picker = (window as unknown as { showOpenFilePicker?: (options: object) => Promise<LocalFileHandle[]> }).showOpenFilePicker;
    if (!picker) { alert("请使用最新版 Chrome 或 Edge 连接本地 JSON。你仍然可以导出 JSON 备份。"); return; }
    try {
      const [handle] = await picker({ multiple: false, types: [{ description: "论文控制台数据", accept: { "application/json": [".json"] } }] });
      await loadFromHandle(handle, true);
    } catch { /* The user cancelled the picker. */ }
  };
  const createDataFile = async () => {
    const picker = (window as unknown as { showSaveFilePicker?: (options: object) => Promise<LocalFileHandle> }).showSaveFilePicker;
    if (!picker) { downloadBackup(); return; }
    try {
      const handle = await picker({ suggestedName: "thesis-dashboard.json", types: [{ description: "论文控制台数据", accept: { "application/json": [".json"] } }] });
      setFileHandle(handle); await rememberHandle(handle); await writeFile(data, handle); setFileState("linked");
    } catch { /* The user cancelled the picker. */ }
  };
  const reloadFile = async () => { if (fileHandle) await loadFromHandle(fileHandle, true); };
  const downloadBackup = () => {
    const blob = new Blob([`${JSON.stringify(data, null, 2)}\n`], { type: "application/json" });
    const url = URL.createObjectURL(blob); const anchor = document.createElement("a");
    anchor.href = url; anchor.download = `thesis-dashboard-${new Date().toISOString().slice(0, 10)}.json`; anchor.click(); URL.revokeObjectURL(url);
  };
  const toggleTask = (taskId: string) => updateData((current) => ({
    ...current, tasks: current.tasks.map((task) => task.id === taskId ? { ...task, status: task.status === "done" ? "todo" : "done" } : task),
  }));
  const setTaskStatus = (taskId: string, status: TaskStatus) => updateData((current) => ({
    ...current, tasks: current.tasks.map((task) => task.id === taskId ? { ...task, status } : task),
  }));
  const chapterName = (chapterId: string) => data.chapters.find((chapter) => chapter.id === chapterId)?.title ?? "未分配";

  return <main className="app-shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark">S</span><div><strong>Sweet Spot</strong><span>论文研究控制台</span></div></div>
      <nav className="nav-list" aria-label="主导航">
        {views.map((item) => <button key={item.id} className={view === item.id ? "nav-item active" : "nav-item"} onClick={() => setView(item.id)}>
          <span className="nav-glyph">{item.short}</span>{item.label}
          {item.id === "tasks" && <em>{openTasks.length}</em>}
          {item.id === "feedback" && <em>{data.feedback.filter((entry) => entry.status === "open").length}</em>}
        </button>)}
      </nav>
      <div className="sidebar-foot"><div className="mini-progress"><span><b>{overallProgress}%</b> 总体进度</span><ProgressBar value={overallProgress} /></div><p>进度由 {data.tasks.filter((task) => task.status === "done").length}/{data.tasks.length} 项 Todo 自动计算</p></div>
    </aside>

    <section className="workspace">
      <header className="topbar">
        <div><p className="eyebrow">TU Berlin · Masterarbeit</p><h1>{data.meta.title}</h1></div>
        <div className="top-actions">
          <div className={`file-indicator file-${fileState}`}><span />{fileHandle ? (fileState === "saving" ? "正在保存" : fileState === "error" ? "保存失败" : "已连接本地数据") : "尚未连接数据文件"}</div>
          {fileHandle ? <button className="button secondary" onClick={reloadFile}>从文件重载</button> : <button className="button secondary" onClick={openDataFile}>连接数据文件</button>}
          <button className="button ghost" onClick={fileHandle ? () => void writeFile(data) : createDataFile}>{fileHandle ? "立即保存" : "新建数据文件"}</button>
        </div>
      </header>
      {!fileHandle && <div className="connect-banner"><div className="connect-icon">↔</div><div><strong>连接同一份 JSON，网页和 AI 才能同步更新</strong><p>选择项目中的 <code>data/thesis-dashboard.json</code>。网页编辑会自动写回，Codex 修改后点击“从文件重载”即可看到变化。</p></div><button className="button primary" onClick={openDataFile}>现在连接</button></div>}
      {view === "overview" && <Overview data={data} overallProgress={overallProgress} chapterProgress={chapterProgress} activeTasks={activeTasks} blockedTasks={blockedTasks} onToggleTask={toggleTask} onOpenChapter={(chapterId) => { setSelectedChapter(chapterId); setView("structure"); }} onNavigate={setView} />}
      {view === "structure" && <StructureView data={data} chapterProgress={chapterProgress} selectedChapter={selectedChapter} setSelectedChapter={setSelectedChapter} onToggleTask={toggleTask} updateData={updateData} />}
      {view === "tasks" && <TasksView data={data} filter={taskFilter} setFilter={setTaskFilter} search={search} setSearch={setSearch} chapterName={chapterName} onToggleTask={toggleTask} onSetStatus={setTaskStatus} onAdd={() => setModal("task")} />}
      {view === "references" && <ReferencesView data={data} chapterName={chapterName} onAdd={() => setModal("reference")} onStatus={(referenceId, status) => updateData((current) => ({ ...current, references: current.references.map((reference) => reference.id === referenceId ? { ...reference, status } : reference) }))} />}
      {view === "feedback" && <FeedbackView data={data} chapterName={chapterName} onAdd={() => setModal("feedback")} />}
      {view === "experiments" && <ExperimentsView data={data} />}
    </section>

    {modal === "task" && <TaskModal chapters={data.chapters} onClose={() => setModal(null)} onSave={(task) => { updateData((current) => ({ ...current, tasks: [...current.tasks, task] })); setModal(null); }} />}
    {modal === "reference" && <ReferenceModal chapters={data.chapters} onClose={() => setModal(null)} onSave={(reference) => { updateData((current) => ({ ...current, references: [...current.references, reference] })); setModal(null); }} />}
    {modal === "feedback" && <FeedbackModal chapters={data.chapters} onClose={() => setModal(null)} onSave={(feedback) => { updateData((current) => ({ ...current, feedback: [feedback, ...current.feedback] })); setModal(null); }} />}
  </main>;
}

function Overview({ data, overallProgress, chapterProgress, activeTasks, blockedTasks, onToggleTask, onOpenChapter, onNavigate }: {
  data: DashboardData; overallProgress: number; chapterProgress: Record<string, number>; activeTasks: Task[]; blockedTasks: Task[];
  onToggleTask: (id: string) => void; onOpenChapter: (id: string) => void; onNavigate: (view: View) => void;
}) {
  return <div className="view-content">
    <section className="overview-hero"><div className="hero-progress"><ProgressRing value={overallProgress} /><div><p className="eyebrow">当前阶段</p><h2>{data.meta.currentPhase}</h2><p>{data.meta.researchQuestion}</p></div></div><div className="milestone-card"><span>下一里程碑</span><strong>{data.meta.nextMilestone}</strong><small>最后更新 · {data.meta.updatedAt}</small></div></section>
    <section className="metric-grid">
      <button className="metric-card" onClick={() => onNavigate("structure")}><span>论文章节</span><strong>{data.chapters.length}</strong><small>结构已建立</small></button>
      <button className="metric-card" onClick={() => onNavigate("tasks")}><span>待办任务</span><strong>{data.tasks.filter((task) => task.status !== "done").length}</strong><small>{activeTasks.length} 项正在进行</small></button>
      <button className="metric-card" onClick={() => onNavigate("references")}><span>参考文献</span><strong>{data.references.length}</strong><small>{data.references.filter((ref) => ref.status === "reading").length} 篇阅读中</small></button>
      <button className="metric-card warning" onClick={() => onNavigate("feedback")}><span>待确认问题</span><strong>{blockedTasks.length + data.decisions.filter((decision) => decision.status === "open").length}</strong><small>需要导师或研究决策</small></button>
    </section>
    <section className="dashboard-grid">
      <article className="panel chapters-panel"><header className="panel-header"><div><p className="eyebrow">Thesis outline</p><h2>章节进度</h2></div><button className="text-button" onClick={() => onNavigate("structure")}>查看完整结构 →</button></header>
        <div className="chapter-list">{data.chapters.map((chapter) => { const tasks = data.tasks.filter((task) => task.chapterId === chapter.id); return <button className="chapter-row" key={chapter.id} onClick={() => onOpenChapter(chapter.id)}><span className="chapter-number">{chapter.number}</span><span className="chapter-name"><strong>{chapter.title}</strong><small>{chapter.subtitle}</small></span><span className="chapter-bar"><ProgressBar value={chapterProgress[chapter.id]} /><small>{tasks.filter((task) => task.status === "done").length}/{tasks.length} Todo</small></span><b>{chapterProgress[chapter.id]}%</b></button>; })}</div>
      </article>
      <div className="right-stack">
        <article className="panel focus-panel"><header className="panel-header"><div><p className="eyebrow">Now</p><h2>最近需要做什么</h2></div></header><div className="task-list compact">{activeTasks.concat(data.tasks.filter((task) => task.status === "todo" && task.priority === "high").slice(0, Math.max(0, 4 - activeTasks.length))).slice(0, 4).map((task) => <label className="task-row" key={task.id}><input type="checkbox" checked={task.status === "done"} onChange={() => onToggleTask(task.id)} /><span><strong>{task.title}</strong><small>{data.chapters.find((chapter) => chapter.id === task.chapterId)?.title}</small></span><StatusPill status={task.status} /></label>)}</div></article>
        <article className="panel decision-panel"><header className="panel-header"><div><p className="eyebrow">Open decisions</p><h2>等待确认</h2></div></header>{data.decisions.filter((decision) => decision.status === "open").slice(0, 2).map((decision) => <div className="decision-item" key={decision.id}><span>?</span><div><strong>{decision.title}</strong><p>{decision.detail}</p></div></div>)}</article>
      </div>
    </section>
  </div>;
}

function StructureView({ data, chapterProgress, selectedChapter, setSelectedChapter, onToggleTask, updateData }: {
  data: DashboardData; chapterProgress: Record<string, number>; selectedChapter: string | null; setSelectedChapter: (id: string | null) => void;
  onToggleTask: (id: string) => void; updateData: (updater: (current: DashboardData) => DashboardData) => void;
}) {
  const selected = data.chapters.find((chapter) => chapter.id === selectedChapter) ?? null;
  const [newSection, setNewSection] = useState("");
  const updateChapter = (chapterId: string, patch: Partial<Chapter>) => updateData((current) => ({ ...current, chapters: current.chapters.map((chapter) => chapter.id === chapterId ? { ...chapter, ...patch } : chapter) }));
  return <div className="view-content">
    <header className="view-header"><div><p className="eyebrow">Thesis outline</p><h2>论文结构</h2><p>点击章节可编辑标题、目标和小节；进度由该章节 Todo 自动计算。</p></div></header>
    <section className="outline-grid">{data.chapters.map((chapter) => <button className="outline-card" key={chapter.id} onClick={() => setSelectedChapter(chapter.id)}><div className="outline-top"><span>{chapter.number}</span><b>{chapterProgress[chapter.id]}%</b></div><h3>{chapter.title}</h3><small>{chapter.subtitle}</small><p>{chapter.goal}</p><ProgressBar value={chapterProgress[chapter.id]} /><div className="section-preview">{chapter.sections.slice(0, 3).map((section) => <span key={section}>{section}</span>)}</div></button>)}</section>
    {selected && <div className="drawer-backdrop" onMouseDown={() => setSelectedChapter(null)}><aside className="drawer" onMouseDown={(event) => event.stopPropagation()}><header className="drawer-header"><span className="chapter-number large">{selected.number}</span><div><p className="eyebrow">章节详情</p><h2>{selected.title}</h2></div><button className="icon-button" onClick={() => setSelectedChapter(null)}>×</button></header><div className="drawer-content">
      <label className="field"><span>章节标题</span><input value={selected.title} onChange={(event) => updateChapter(selected.id, { title: event.target.value })} /></label>
      <label className="field"><span>英文副标题</span><input value={selected.subtitle} onChange={(event) => updateChapter(selected.id, { subtitle: event.target.value })} /></label>
      <label className="field"><span>本章目标</span><textarea rows={3} value={selected.goal} onChange={(event) => updateChapter(selected.id, { goal: event.target.value })} /></label>
      <section className="drawer-section"><div className="drawer-section-title"><h3>小节结构</h3><span>{selected.sections.length} 节</span></div><div className="editable-sections">{selected.sections.map((section, index) => <div key={`${selected.id}-${index}`}><span>{selected.number}.{index + 1}</span><input value={section} onChange={(event) => { const sections = [...selected.sections]; sections[index] = event.target.value; updateChapter(selected.id, { sections }); }} /><button onClick={() => updateChapter(selected.id, { sections: selected.sections.filter((_, itemIndex) => itemIndex !== index) })} aria-label="删除小节">×</button></div>)}<form onSubmit={(event) => { event.preventDefault(); if (!newSection.trim()) return; updateChapter(selected.id, { sections: [...selected.sections, newSection.trim()] }); setNewSection(""); }} className="add-section"><input placeholder="添加新小节" value={newSection} onChange={(event) => setNewSection(event.target.value)} /><button className="button secondary">添加</button></form></div></section>
      <section className="drawer-section"><div className="drawer-section-title"><h3>章节 Todo</h3><span>{chapterProgress[selected.id]}%</span></div><ProgressBar value={chapterProgress[selected.id]} /><div className="task-list compact spaced">{data.tasks.filter((task) => task.chapterId === selected.id).map((task) => <label className="task-row" key={task.id}><input type="checkbox" checked={task.status === "done"} onChange={() => onToggleTask(task.id)} /><span><strong>{task.title}</strong><small>{task.type}</small></span><StatusPill status={task.status} /></label>)}</div></section>
      <section className="drawer-section related-counts"><div><strong>{data.references.filter((ref) => ref.chapterIds.includes(selected.id)).length}</strong><span>相关文献</span></div><div><strong>{data.feedback.filter((entry) => entry.chapterIds.includes(selected.id)).length}</strong><span>导师意见</span></div><div><strong>{data.experiments.filter((experiment) => experiment.taskIds.some((taskId) => data.tasks.find((task) => task.id === taskId)?.chapterId === selected.id)).length}</strong><span>关联实验</span></div></section>
    </div></aside></div>}
  </div>;
}

function TasksView({ data, filter, setFilter, search, setSearch, chapterName, onToggleTask, onSetStatus, onAdd }: {
  data: DashboardData; filter: TaskStatus | "all"; setFilter: (filter: TaskStatus | "all") => void; search: string; setSearch: (value: string) => void;
  chapterName: (id: string) => string; onToggleTask: (id: string) => void; onSetStatus: (id: string, status: TaskStatus) => void; onAdd: () => void;
}) {
  const filtered = data.tasks.filter((task) => (filter === "all" || task.status === filter) && task.title.toLowerCase().includes(search.toLowerCase()));
  return <div className="view-content"><header className="view-header actions-header"><div><p className="eyebrow">Action list</p><h2>任务</h2><p>完成任务后，对应章节和总体进度会自动更新。</p></div><button className="button primary" onClick={onAdd}>＋ 添加任务</button></header>
    <div className="toolbar"><div className="segmented">{(["all", "doing", "todo", "blocked", "done"] as const).map((status) => <button key={status} className={filter === status ? "active" : ""} onClick={() => setFilter(status)}>{status === "all" ? "全部" : statusLabel[status]}</button>)}</div><input className="search-input" placeholder="搜索任务…" value={search} onChange={(event) => setSearch(event.target.value)} /></div>
    <section className="panel table-panel"><div className="task-table-head"><span>任务</span><span>章节</span><span>优先级</span><span>状态</span></div>{filtered.map((task) => <div className="task-table-row" key={task.id}><label><input type="checkbox" checked={task.status === "done"} onChange={() => onToggleTask(task.id)} /><span>{task.title}<small>{task.type}</small></span></label><span>{chapterName(task.chapterId)}</span><span><i className={`priority priority-${task.priority}`} />{priorityLabel[task.priority]}</span><select value={task.status} onChange={(event) => onSetStatus(task.id, event.target.value as TaskStatus)}><option value="todo">待开始</option><option value="doing">进行中</option><option value="blocked">待确认</option><option value="done">已完成</option></select></div>)}</section>
  </div>;
}

function ReferencesView({ data, chapterName, onAdd, onStatus }: { data: DashboardData; chapterName: (id: string) => string; onAdd: () => void; onStatus: (id: string, status: string) => void }) {
  return <div className="view-content"><header className="view-header actions-header"><div><p className="eyebrow">Evidence library</p><h2>参考文献</h2><p>把每篇文献关联到章节，并记录它具体支持什么。</p></div><button className="button primary" onClick={onAdd}>＋ 添加文献</button></header><section className="reference-grid">{data.references.map((reference) => <article className="reference-card" key={reference.id}><div className="reference-top"><code>{reference.key}</code><select value={reference.status} onChange={(event) => onStatus(reference.id, event.target.value)}><option value="todo">待读</option><option value="reading">阅读中</option><option value="using">使用中</option><option value="done">已完成</option></select></div><h3>{reference.title}</h3><p>{reference.authors} · {reference.year}</p><blockquote>{reference.note}</blockquote><div className="tag-row">{reference.chapterIds.map((chapterId) => <span key={chapterId}>{chapterName(chapterId)}</span>)}</div>{reference.url && <a href={reference.url} target="_blank" rel="noreferrer">打开来源 ↗</a>}</article>)}</section></div>;
}

function FeedbackView({ data, chapterName, onAdd }: { data: DashboardData; chapterName: (id: string) => string; onAdd: () => void }) {
  return <div className="view-content"><header className="view-header actions-header"><div><p className="eyebrow">Supervisor log</p><h2>导师意见与研究决策</h2><p>保留原始意见、行动项和落实状态，避免只记住结论。</p></div><button className="button primary" onClick={onAdd}>＋ 记录新意见</button></header><section className="feedback-layout"><div className="timeline">{data.feedback.map((entry) => <article className="timeline-item" key={entry.id}><div className="timeline-dot" /><div className="timeline-card"><header><div><strong>{entry.author}</strong><span>{entry.date} · {entry.source}</span></div><StatusPill status={entry.status} /></header><p>{entry.summary}</p><div className="action-note"><span>下一步</span>{entry.action}</div><div className="tag-row">{entry.chapterIds.map((chapterId) => <span key={chapterId}>{chapterName(chapterId)}</span>)}</div></div></article>)}</div><aside className="panel decisions-list"><header className="panel-header"><div><p className="eyebrow">Decision log</p><h2>关键决策</h2></div></header>{data.decisions.map((decision) => <div className="decision-log" key={decision.id}><div><span>{decision.date}</span><StatusPill status={decision.status} /></div><strong>{decision.title}</strong><p>{decision.detail}</p></div>)}</aside></section></div>;
}

function ExperimentsView({ data }: { data: DashboardData }) {
  return <div className="view-content"><header className="view-header"><div><p className="eyebrow">Simulation pipeline</p><h2>实验与数据</h2><p>这里跟踪实验是否“准备好用于论文”，原始数据仍保存在项目目录中。</p></div></header><section className="experiment-flow">{data.experiments.map((experiment, index) => { const tasks = data.tasks.filter((task) => experiment.taskIds.includes(task.id)); const progress = progressOf(tasks); return <article className="experiment-card" key={experiment.id}><div className="experiment-index"><span>{experiment.code}</span>{index < data.experiments.length - 1 && <i />}</div><div className="experiment-content"><header><div><small>{experiment.rq}</small><h3>{experiment.title}</h3></div><StatusPill status={experiment.status} /></header><ProgressBar value={progress} /><div className="experiment-meta"><span>{progress}% · {tasks.filter((task) => task.status === "done").length}/{tasks.length} Todo</span><span>下一步：{experiment.next}</span></div><div className="experiment-tasks">{tasks.map((task) => <span className={task.status === "done" ? "done" : ""} key={task.id}>{task.title}</span>)}</div></div></article>; })}</section></div>;
}

function TaskModal({ chapters, onClose, onSave }: { chapters: Chapter[]; onClose: () => void; onSave: (task: Task) => void }) {
  const [form, setForm] = useState({ title: "", chapterId: chapters[0]?.id ?? "", priority: "medium" as Priority, status: "todo" as TaskStatus, type: "writing" });
  const submit = (event: FormEvent) => { event.preventDefault(); if (form.title.trim()) onSave({ id: makeId("task"), ...form, title: form.title.trim(), due: "" }); };
  return <Modal title="添加任务" onClose={onClose}><form className="modal-form" onSubmit={submit}><label className="field full"><span>任务内容</span><input autoFocus required value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} placeholder="例如：核验 ALINEA 控制参数" /></label><label className="field"><span>对应章节</span><select value={form.chapterId} onChange={(event) => setForm({ ...form, chapterId: event.target.value })}>{chapters.map((chapter) => <option value={chapter.id} key={chapter.id}>{chapter.number} {chapter.title}</option>)}</select></label><label className="field"><span>类型</span><select value={form.type} onChange={(event) => setForm({ ...form, type: event.target.value })}><option value="writing">写作</option><option value="literature">文献</option><option value="simulation">仿真</option><option value="analysis">分析</option><option value="decision">决策</option><option value="setup">配置</option></select></label><label className="field"><span>优先级</span><select value={form.priority} onChange={(event) => setForm({ ...form, priority: event.target.value as Priority })}><option value="high">高</option><option value="medium">中</option><option value="low">低</option></select></label><label className="field"><span>状态</span><select value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value as TaskStatus })}><option value="todo">待开始</option><option value="doing">进行中</option><option value="blocked">待确认</option><option value="done">已完成</option></select></label><div className="modal-actions"><button type="button" className="button secondary" onClick={onClose}>取消</button><button className="button primary">保存任务</button></div></form></Modal>;
}
function ReferenceModal({ chapters, onClose, onSave }: { chapters: Chapter[]; onClose: () => void; onSave: (reference: Reference) => void }) {
  const [form, setForm] = useState({ key: "", authors: "", year: "", title: "", status: "todo", chapterIds: [] as string[], url: "", note: "" });
  const submit = (event: FormEvent) => { event.preventDefault(); if (form.title.trim()) onSave({ id: makeId("ref"), ...form, key: form.key || `Ref${new Date().getFullYear()}` }); };
  return <Modal title="添加参考文献" onClose={onClose}><form className="modal-form" onSubmit={submit}><label className="field full"><span>文献标题</span><input autoFocus required value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} /></label><label className="field"><span>Citation key</span><input value={form.key} onChange={(event) => setForm({ ...form, key: event.target.value })} placeholder="Author2026" /></label><label className="field"><span>年份</span><input value={form.year} onChange={(event) => setForm({ ...form, year: event.target.value })} /></label><label className="field full"><span>作者</span><input value={form.authors} onChange={(event) => setForm({ ...form, authors: event.target.value })} /></label><label className="field full"><span>链接 / DOI</span><input value={form.url} onChange={(event) => setForm({ ...form, url: event.target.value })} /></label><label className="field full"><span>用途或支持的论点</span><textarea rows={3} value={form.note} onChange={(event) => setForm({ ...form, note: event.target.value })} /></label><ChapterChecks chapters={chapters} selected={form.chapterIds} onChange={(chapterIds) => setForm({ ...form, chapterIds })} /><div className="modal-actions"><button type="button" className="button secondary" onClick={onClose}>取消</button><button className="button primary">保存文献</button></div></form></Modal>;
}
function FeedbackModal({ chapters, onClose, onSave }: { chapters: Chapter[]; onClose: () => void; onSave: (feedback: Feedback) => void }) {
  const [form, setForm] = useState({ date: new Date().toISOString().slice(0, 10), author: "Robert Hilbrich", summary: "", action: "", status: "open", chapterIds: [] as string[], source: "会谈" });
  const submit = (event: FormEvent) => { event.preventDefault(); if (form.summary.trim()) onSave({ id: makeId("feedback"), ...form }); };
  return <Modal title="记录导师意见" onClose={onClose}><form className="modal-form" onSubmit={submit}><label className="field"><span>日期</span><input type="date" value={form.date} onChange={(event) => setForm({ ...form, date: event.target.value })} /></label><label className="field"><span>提出者</span><input value={form.author} onChange={(event) => setForm({ ...form, author: event.target.value })} /></label><label className="field full"><span>原始意见或准确摘要</span><textarea autoFocus required rows={4} value={form.summary} onChange={(event) => setForm({ ...form, summary: event.target.value })} /></label><label className="field full"><span>需要采取的行动</span><textarea rows={3} value={form.action} onChange={(event) => setForm({ ...form, action: event.target.value })} /></label><label className="field"><span>来源</span><select value={form.source} onChange={(event) => setForm({ ...form, source: event.target.value })}><option>会谈</option><option>邮件</option><option>批注</option><option>汇报反馈</option></select></label><label className="field"><span>状态</span><select value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value })}><option value="open">待处理</option><option value="doing">落实中</option><option value="accepted">已采纳</option><option value="done">已完成</option></select></label><ChapterChecks chapters={chapters} selected={form.chapterIds} onChange={(chapterIds) => setForm({ ...form, chapterIds })} /><div className="modal-actions"><button type="button" className="button secondary" onClick={onClose}>取消</button><button className="button primary">保存意见</button></div></form></Modal>;
}
function ChapterChecks({ chapters, selected, onChange }: { chapters: Chapter[]; selected: string[]; onChange: (ids: string[]) => void }) {
  return <fieldset className="field full checkbox-field"><legend>关联章节</legend>{chapters.map((chapter) => <label key={chapter.id}><input type="checkbox" checked={selected.includes(chapter.id)} onChange={() => onChange(selected.includes(chapter.id) ? selected.filter((item) => item !== chapter.id) : [...selected, chapter.id])} />{chapter.number} {chapter.title}</label>)}</fieldset>;
}
